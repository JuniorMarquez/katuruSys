/**
 * PesoController
 *
 * @description :: Server-side logic for managing pesoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

