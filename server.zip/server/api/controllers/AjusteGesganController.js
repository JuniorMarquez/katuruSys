/**
 * AjusteGesganController
 *
 * @description :: Server-side logic for managing ajustegesgans
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

