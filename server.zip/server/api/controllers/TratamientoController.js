/**
 * TratamientoController
 *
 * @description :: Server-side logic for managing tratamientoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

