/**
 * TipoBanoController
 *
 * @description :: Server-side logic for managing tipobanoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

