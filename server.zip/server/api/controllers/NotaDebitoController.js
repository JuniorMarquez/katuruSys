/**
 * NotaDebitoController
 *
 * @description :: Server-side logic for managing notadebitoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

