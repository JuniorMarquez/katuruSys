/**
 * CateController
 *
 * @description :: Server-side logic for managing cates
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

