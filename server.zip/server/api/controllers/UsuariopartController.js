/**
 * UsuariopartController
 *
 * @description :: Server-side logic for managing usuarioparts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

