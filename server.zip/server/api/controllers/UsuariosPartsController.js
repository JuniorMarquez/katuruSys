/**
 * UsuariosPartsController
 *
 * @description :: Server-side logic for managing usuariosparts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

