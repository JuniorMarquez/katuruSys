/**
 * ProveedorController
 *
 * @description :: Server-side logic for managing proveedors
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

