/**
 * SucursalController
 *
 * @description :: Server-side logic for managing sucursals
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

