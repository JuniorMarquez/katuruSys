/**
 * AnimalController
 *
 * @description :: Server-side logic for managing animals
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

