/**
 * CancionController
 *
 * @description :: Server-side logic for managing cancions
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

