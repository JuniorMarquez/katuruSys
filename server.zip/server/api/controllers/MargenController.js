/**
 * MargenController
 *
 * @description :: Server-side logic for managing margens
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

