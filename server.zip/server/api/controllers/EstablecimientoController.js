/**
 * EstablecimientoController
 *
 * @description :: Server-side logic for managing establecimientoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

