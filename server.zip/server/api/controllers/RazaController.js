/**
 * RazaController
 *
 * @description :: Server-side logic for managing razas
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

