/**
 * CuentaPorCobrarController
 *
 * @description :: Server-side logic for managing cuentaporcobrars
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

