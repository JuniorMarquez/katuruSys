/**
 * OrdenoController
 *
 * @description :: Server-side logic for managing ordenoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

