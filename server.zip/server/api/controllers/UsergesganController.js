/**
 * UsergesganController
 *
 * @description :: Server-side logic for managing usergesgans
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

