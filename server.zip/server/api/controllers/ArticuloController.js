/**
 * ArticuloController
 *
 * @description :: Server-side logic for managing articuloes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

