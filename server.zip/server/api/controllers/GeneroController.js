/**
 * GeneroController
 *
 * @description :: Server-side logic for managing generoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

