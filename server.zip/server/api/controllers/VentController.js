/**
 * VentController
 *
 * @description :: Server-side logic for managing vents
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

