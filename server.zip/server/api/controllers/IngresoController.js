/**
 * IngresoController
 *
 * @description :: Server-side logic for managing ingresoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

