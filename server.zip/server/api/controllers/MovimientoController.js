/**
 * MovimientoController
 *
 * @description :: Server-side logic for managing movimientoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

