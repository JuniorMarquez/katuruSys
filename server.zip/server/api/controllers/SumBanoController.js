/**
 * SumBanoController
 *
 * @description :: Server-side logic for managing sumbanoes
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

