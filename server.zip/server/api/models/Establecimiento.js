/**
* Establecimiento.js
*
* @description :: TODO: You might write a short summary of how this model works and what it represents here.
* @docs        :: http://sailsjs.org/#!documentation/models
*/

module.exports = {

  attributes: {
  	nombreRazon:'string',
  	rubro:'string',
  	direccion: 'string',
  	tel1:'string',
  	tel2:'string',
  	email:'string',
  	web:'string'
  }
};

