app.controller('DashboardCtrl', ['$scope', '$http', '$filter', '$modal', 'MyService', function($scope, $http, $filter,$modal, MyService) {

 $scope.filter = '';


   
	}]);