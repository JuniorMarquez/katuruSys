(function() {
    'use strict';

    app

.factory("MyService", function() {
  return {
    data: {}
  };
});
})();